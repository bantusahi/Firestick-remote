package com.example.fireremote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import dadb.AdbKeyPair
import dadb.Dadb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { Remote() } } }
    }
}

private object Key {
    const val UP = 19; const val DOWN = 20; const val LEFT = 21; const val RIGHT = 22
    const val OK = 23; const val BACK = 4; const val HOME = 3; const val MENU = 82
    const val PLAY = 85; const val REW = 89; const val FF = 90
    const val VOL_UP = 24; const val VOL_DOWN = 25; const val MUTE = 164
    const val SLEEP = 223
}

@Composable
fun Remote() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val prefs = remember { ctx.getSharedPreferences("fr", 0) }
    var ip by remember { mutableStateOf(prefs.getString("ip", "") ?: "") }
    var status by remember { mutableStateOf("Not connected") }
    var adb by remember { mutableStateOf<Dadb?>(null) }

    fun connect() = scope.launch {
        status = "Connecting… accept the prompt on your TV"
        try {
            val d = withContext(Dispatchers.IO) {
                val priv = File(ctx.filesDir, "adbkey")
                val pub = File(ctx.filesDir, "adbkey.pub")
                if (!priv.exists()) AdbKeyPair.generate(priv, pub)
                val dd = Dadb.create(ip.trim(), 5555, AdbKeyPair.read(priv, pub))
                dd.shell("echo ok") // forces auth
                dd
            }
            adb?.close(); adb = d
            prefs.edit().putString("ip", ip.trim()).apply()
            status = "Connected"
        } catch (e: Exception) {
            adb = null; status = "Failed: ${e.message}"
        }
    }

    fun press(code: Int) {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        val d = adb ?: run { status = "Not connected"; return }
        scope.launch {
            try { withContext(Dispatchers.IO) { d.shell("input keyevent $code") } }
            catch (e: Exception) { adb = null; status = "Disconnected: ${e.message}" }
        }
    }

    @Composable
    fun Btn(label: String, code: Int, w: Int = 90) =
        FilledTonalButton(onClick = { press(code) }, modifier = Modifier.width(w.dp).height(64.dp)) { Text(label) }

    Column(
        Modifier.fillMaxSize().padding(20.dp).systemBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = ip, onValueChange = { ip = it }, singleLine = true,
                label = { Text("Fire Stick IP") }, modifier = Modifier.weight(1f)
            )
            Button(onClick = { connect() }) { Text("Connect") }
        }
        Text(status, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))

        Btn("▲", Key.UP)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("◀", Key.LEFT)
            Button(onClick = { press(Key.OK) }, modifier = Modifier.width(90.dp).height(64.dp)) { Text("OK") }
            Btn("▶", Key.RIGHT)
        }
        Btn("▼", Key.DOWN)
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("Back", Key.BACK); Btn("Home", Key.HOME); Btn("Menu", Key.MENU)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("⏪", Key.REW); Btn("⏯", Key.PLAY); Btn("⏩", Key.FF)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("Vol -", Key.VOL_DOWN); Btn("Mute", Key.MUTE); Btn("Vol +", Key.VOL_UP)
        }
        Btn("Sleep", Key.SLEEP, 150)
    }
}
