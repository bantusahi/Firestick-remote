package com.example.fireremote

import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.tananaev.adblib.AdbBase64
import com.tananaev.adblib.AdbConnection
import com.tananaev.adblib.AdbCrypto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.Socket

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { Remote() } } }
    }
}

private object Key {
    const val UP = 19; const val DOWN = 20; const val LEFT = 21; const val RIGHT = 22
    const val OK = 23; const val BACK = 4; const val HOME = 3; const val MENU = 82
    const val PLAY = 85; const val REW = 89; const val FF = 90
    const val SLEEP = 223; const val DEL = 67; const val ENTER = 66
}

private fun shell(c: AdbConnection, cmd: String) {
    val st = c.open("shell:$cmd")
    try { while (true) st.read() } catch (_: IOException) {}
    try { st.close() } catch (_: Exception) {}
}

@Composable
fun Remote() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val prefs = remember { ctx.getSharedPreferences("fr", 0) }
    var ip by remember { mutableStateOf(prefs.getString("ip", "") ?: "") }
    var status by remember { mutableStateOf("v3 - Not connected") }
    var adb by remember { mutableStateOf<AdbConnection?>(null) }
    var text by remember { mutableStateOf("") }

    fun connect() = scope.launch {
        status = "Connecting… accept the prompt on your TV"
        try {
            val d = withContext(Dispatchers.IO) {
                val b64 = AdbBase64 { Base64.encodeToString(it, Base64.NO_WRAP) }
                val priv = File(ctx.filesDir, "adbkey")
                val pub = File(ctx.filesDir, "adbkey.pub")
                val crypto = if (priv.exists() && pub.exists()) AdbCrypto.loadAdbKeyPair(b64, priv, pub)
                else AdbCrypto.generateAdbKeyPair(b64).also { it.saveAdbKeyPair(priv, pub) }
                val sock = Socket(ip.trim(), 5555)
                val c = AdbConnection.create(sock, crypto)
                c.connect()
                c
            }
            adb?.close(); adb = d
            prefs.edit().putString("ip", ip.trim()).apply()
            status = "Connected"
        } catch (e: Exception) {
            adb = null; status = "Failed: ${e.message}"
        }
    }

    fun run(cmd: String, onDone: () -> Unit = {}) {
        val d = adb ?: run { status = "Not connected"; return }
        scope.launch {
            try { withContext(Dispatchers.IO) { shell(d, cmd) }; onDone() }
            catch (e: Exception) { adb = null; status = "Disconnected: ${e.message}" }
        }
    }

    fun press(code: Int) {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        run("input keyevent $code")
    }

    fun sendText() {
        if (text.isEmpty()) return
        val safe = text.replace("'", "'\\''").replace(" ", "%s")
        run("input text '$safe'") { text = "" }
    }

    @Composable
    fun Btn(label: String, code: Int, w: Int = 90) =
        FilledTonalButton(onClick = { press(code) }, modifier = Modifier.width(w.dp).height(64.dp)) { Text(label) }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = ip, onValueChange = { ip = it }, singleLine = true,
                label = { Text("Fire Stick IP") }, modifier = Modifier.weight(1f)
            )
            Button(onClick = { connect() }) { Text("Connect") }
        }
        Text(status, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))

        Btn("▲", Key.UP)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("◀", Key.LEFT)
            Button(onClick = { press(Key.OK) }, modifier = Modifier.width(90.dp).height(64.dp)) { Text("OK") }
            Btn("▶", Key.RIGHT)
        }
        Btn("▼", Key.DOWN)
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("Back", Key.BACK); Btn("Home", Key.HOME); Btn("Menu", Key.MENU)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("⏪", Key.REW); Btn("⏯", Key.PLAY); Btn("⏩", Key.FF)
        }
        Btn("Sleep", Key.SLEEP, 150)

        HorizontalDivider()
        Text("Keyboard (select a text box on the TV first)", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, singleLine = true,
                label = { Text("Type here") }, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { sendText() })
            )
            Button(onClick = { sendText() }) { Text("Send") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("⌫ Delete", Key.DEL, 140); Btn("Enter ↵", Key.ENTER, 140)
        }
    }
}
